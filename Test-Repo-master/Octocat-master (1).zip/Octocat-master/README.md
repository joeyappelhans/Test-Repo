# Octocat

### Directions
Our goal is to make a JavaScript file in Atom and upload it to the same Test Repo that we made yesterday. I would like you to make a constructor function and 3 object instances of these objects.

### Octocat
The type of these objects are called Octocats. This should be the name of your constructor function.

  - Instance Variables
    -  name: its name.
    -  arms: the number of arms your octocat has.

  -  Instance Functions
    -  slap: This function runs a for-loop. Each time the function runs through the for-loop you will log "SLAP" to the console. This loop should run once for each arm that your octocat has.

### Upload
Do not forget to upload your code to the Test Repo. Drag only the file and not the folder.
