//Write your constructor function below.
//You should have 2 instance variables and 1 instance function included.











//Write your 3 new octocat objects below here.
